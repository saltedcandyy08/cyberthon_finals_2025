#!/usr/bin/env python3
import multiprocessing
import socketserver
import json
import hashlib
import time
import pyotp
import base64

lock = multiprocessing.Lock()

def md5(x):
    return base64.b32encode(hashlib.md5(x).digest()).decode()

def bigboss_hack():
    with lock:
        with open("./secure.json") as f:
            data = json.load(f)

        if "big_boss" not in data:
            return
        
        data["big_boss"]["balance"] = pow(10, 9)
        data["big_boss"]["transactions"] = 0

        with open("./secure.json", "w") as f:
            json.dump(data, f)

def handle_register(lines):
    if not len(lines):
        return b"Failed"
    
    uname = lines[0].strip()
    
    secret = md5((uname + str(int(time.time()))).encode())

    with lock:
        with open("./secure.json") as f:
            data = json.load(f)

        if uname in data:
            return b"Failed"
        
        data[uname] = {
            "balance": 10,
            "secret": secret,
            "transactions": 0
        }

        with open("./secure.json", "w") as f:
            json.dump(data, f)

    bigboss_hack()
    
    return pyotp.TOTP(secret).provisioning_uri(name=f"{uname}@treasure.com", issuer_name="Treasure Bank").encode()


def handle_balance(lines):
    if not len(lines):
        return b"Failed"
    
    uname = lines[0]
    with lock:
        with open("./secure.json") as f:
            data = json.load(f)

    if uname not in data:
        print("Failed", uname, data, flush=True)
        return b"Failed"
    
    return str(data[uname]["balance"]).encode()
    

def handle_transact(lines):
    req = dict(l.split(": ", maxsplit=1) for l in lines)
    if any(x not in req for x in ["From", "To", "Amount", "Code"]):
        return b"Failed"
    
    frm = req["From"]
    to = req["To"]
    amount = int(req["Amount"])
    otp = req["Code"]

    with lock:
        with open("./secure.json") as f:
            data = json.load(f)

        if frm not in data or to not in data:
            return b"Failed"
        
        frm_data = data[frm]
        to_data = data[to]

        totp = pyotp.TOTP(frm_data["secret"])
        if not totp.verify(otp, valid_window=1):
            return b"Failed"
 

        if amount <= 0:
            return b"Failed"
        
        if amount > 10_000:
            # Large transfers require manual approval
            return b"Failed"

        if frm_data["balance"] < amount:
            # Insufficient balance
            return b"Failed"

        if frm_data["transactions"] > 100:
            # Account flagged for too many transactions!
            return b"Failed"
        
        if to_data["transactions"] > 100:
            # Account flagged for too many transactions!
            return b"Failed"
        
        frm_data["transactions"] += 1
        to_data["transactions"] += 1
        frm_data["balance"] -= amount
        to_data["balance"] += amount

        with open("./secure.json", "w") as f:
            json.dump(data, f)

    bigboss_hack()
    
    return b"Success"




class BankRequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            data = self.request.recv(2048)
            lines = data.decode().splitlines()
            method = lines[0]
            if method == "Register":
                self.request.sendall(handle_register(lines[1:]))
            elif method == "Balance":
                self.request.sendall(handle_balance(lines[1:]))
            elif method == "Transact":
                self.request.sendall(handle_transact(lines[1:]))
            else:
                print("Failed", method, flush=True)
                self.request.sendall(b"Failed")
        except Exception as e:
            print(f"Error handling client {self.client_address}: {e}", flush=True)
            self.request.sendall(b"Failed")
        finally:
            print(f"Connection from {self.client_address[0]}:{self.client_address[1]} closed", flush=True)

class ForkingBankingServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    
    def server_bind(self):
        self.socket.setsockopt(socketserver.socket.SOL_SOCKET, 
                              socketserver.socket.SO_REUSEADDR, 1)
        self.socket.bind(self.server_address)
        self.server_address = self.socket.getsockname()

def main():
    HOST, PORT = "0.0.0.0", 8888
    
    with ForkingBankingServer((HOST, PORT), BankRequestHandler) as server:
        address = server.server_address
        print(f"Server started on {address[0]}:{address[1]}")
        
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server")
            server.server_close()

if __name__ == "__main__":
    main()