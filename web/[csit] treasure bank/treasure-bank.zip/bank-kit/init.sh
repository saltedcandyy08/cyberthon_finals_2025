#!/bin/sh

echo '{"big_boss": {"balance": 1000000000, "secret": "REDACTED", "transactions": 0}}' > /secure.json