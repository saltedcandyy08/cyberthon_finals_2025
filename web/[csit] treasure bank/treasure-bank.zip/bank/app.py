from flask import Flask, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
from datetime import datetime
from util import do_register, do_balance, do_transfer
import qrcode
import qrcode.image.svg
import pyotp

app = Flask(__name__)
flag = open("./flag.txt").read()
app.config['SECRET_KEY'] = flag
app.config['DATABASE'] = 'banking.db'

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.executescript(f.read())
        db.commit()

@app.cli.command('init-db')
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    print('Initialized the database.')

def login_required(view):
    def wrapped_view(**kwargs):
        if 'username' not in session:
            print("DIED")
            return redirect(url_for('login'))
        return view(**kwargs)
    wrapped_view.__name__ = view.__name__
    return wrapped_view

@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form.get('username', None)
        password = request.form.get('password', None)
        
        db = get_db()
        error = None

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        elif len(password) < 8:
            error = "Password must be at least 8 characters long."
        elif any(x in username for x in "!@#$%^&<>?{~`\t\b\r\n}*();'[],/.!@#$%"):
            error = "Special characters not allowed!"
        elif db.execute('SELECT username FROM user WHERE username = ?', (username,)).fetchone() is not None:
            error = f"User {username} is already registered."
        
        if error is None:
            res = do_register(username)
            if res is None:
                flash("Registration failed", "danger")
            else:
                db.execute(
                    'INSERT INTO user (username, password, timestamp) VALUES (?, ?, ?)',
                    (username, generate_password_hash(password), datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                )
                db.commit()
                session["2fa"] = res
                session["2fa_user"] = username
                return redirect(url_for('two_fa'))
        
        flash(error, "danger")
    
    return render_template('register.html')


@app.route('/2fa', methods=('GET', 'POST'))
def two_fa():
    if "2fa" not in session:
        return redirect(url_for('login'))
    qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
            image_factory=qrcode.image.svg.SvgPathImage
        )
    qr.add_data(session["2fa"])
    if request.method == "POST":
        secret = pyotp.parse_uri(session["2fa"]).secret
        otp = request.form.get("otp")
        totp = pyotp.TOTP(secret)
        if totp.verify(otp, valid_window=1):
            db = get_db()
            db.execute(
                    'update user set activated = true where username = ?',
                    (session["2fa_user"], )
                )
            db.commit()
            session.clear()
            flash("Correct OTP! Please proceed to login.", "success")
            return redirect(url_for('login'))
        else:
            print(secret, totp.now(), flush=True)
            flash("Invalid OTP!", "danger")
    return render_template('2fa.html', img=qr.make_image().to_string(encoding='unicode'))


@app.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form.get('username', None)
        password = request.form.get('password', None)
        
        db = get_db()
        error = None

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        
        if error is None:
            user = db.execute('SELECT * FROM user WHERE username = ? and activated = true', (username,)).fetchone()
            
            if user is None:
                error = 'Incorrect username or user not activated.'
            elif not check_password_hash(user['password'], password):
                error = 'Incorrect password.'
            
            if error is None:
                session.clear()
                session['username'] = username
                return redirect(url_for('dashboard'))
        
        flash(error, "danger")
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    
    account = db.execute(
        'SELECT * FROM user WHERE username = ?', (session['username'],)
    ).fetchone()
    balance = do_balance(session['username'])
    if balance is None:
        session.clear()
        flash("Your account has expired! Please make a new one!", "danger")
        return redirect(url_for('register'))
    return render_template('dashboard.html', account=account, balance=balance)

@app.route('/flag')
@login_required
def get_flag():
    balance = do_balance(session['username'])
    if balance is None:
        session.clear()
        flash("Your account has expired! Please make a new one!", "danger")
        return redirect(url_for('register'))
    if balance >= 1000000:
        return render_template('flag.html', flag=flag)
    return redirect(url_for('dashboard'))


@app.route('/transfer', methods=('POST',))
@login_required
def transfer():
    to_username = request.form.get("to", None)
    amount = request.form.get("amount", None)
    otp = request.form.get("otp", None)

    if not do_transfer(session['username'], to_username, amount, otp):
        flash("Transfer failed!", "danger")
    else:
        flash("Transfer success!", "success")
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    if not os.path.exists(app.config['DATABASE']):
        with app.app_context():
            init_db()
    app.run(debug=True, host="0.0.0.0")