import socket

HOST, PORT = "bank-kit", 8888


def do_register(name):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    msg = f"Register\n{name}\n".encode()

    sock.sendall(msg)
    recv = sock.recv(1024)
    if recv.startswith(b"Failed"):
        return
    return recv.decode()


def do_balance(name):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    msg = f"Balance\n{name}\n".encode()

    sock.sendall(msg)
    recv = sock.recv(1024)
    if recv.startswith(b"Failed"):
        return
    return int(recv.decode())

def do_transfer(frm, to, amt, otp):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    msg = f"Transact\nFrom: {frm}\nTo: {to}\nAmount: {amt}\nCode: {otp}".encode()

    sock.sendall(msg)
    recv = sock.recv(1024)
    if recv.startswith(b"Failed"):
        return
    return recv.decode()