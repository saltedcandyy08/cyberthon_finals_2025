-- schema.sql
DROP TABLE IF EXISTS user;

CREATE TABLE user (
  username TEXT PRIMARY KEY,
  password TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  activated BOOLEAN
);


INSERT INTO user (username, password, timestamp, activated) VALUES ("big_boss", "login_disabled", "2025-02-28 15:50:24", 1);