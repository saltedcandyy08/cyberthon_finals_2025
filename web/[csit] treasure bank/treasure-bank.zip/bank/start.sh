crond

flask init-db

gunicorn -w 8 --bind 0.0.0.0:5000 --log-level debug app:app