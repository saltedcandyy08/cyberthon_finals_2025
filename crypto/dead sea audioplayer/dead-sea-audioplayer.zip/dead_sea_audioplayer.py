from Crypto.PublicKey import DSA
from Crypto.Hash import SHA256
from Crypto.Util.number import bytes_to_long, inverse

flag = "Cyberthon{??????????????????}"

class LCG:
    def __init__(self, seed, a, c, m):
        self.state = seed
        self.a = a
        self.c = c
        self.m = m

    def next(self):
        self.state = (self.a * self.state + self.c) % self.m
        return self.state


seed = bytes_to_long(flag.encode())
a = 1664525       
c = 1013904223    
m = 2**256        

lcg = LCG(seed, a, c, m)

for i in range(100):
    lcg.next()

key = DSA.generate(3072)
p = key.p
q = key.q
g = key.g
y = key.y
x = key.x

def sign(message):
    h = SHA256.new(message.encode()).digest()
    h = bytes_to_long(h)  

    k = lcg.next()

    r = pow(g, k, p) % q

    k_inv = inverse(k, q)
    s = (k_inv * (h + x * r)) % q

    return r, s, h

r1, s1, h1 = sign("You search and search, but it's all in vain,")
r2, s2, h2 = sign("My secret stays hidden, locked in the chain.")

print(f"{p = }")
print(f"{q = }")
print(f"{g = }")
print(f"{r1 = }")
print(f"{s1 = }")
print(f"{h1 = }")
print(f"{r2 = }")
print(f"{s2 = }")
print(f"{h2 = }")
