# Treasure Box Creation Process
The treasure box is a cube of side length 30 cm, with designs on the side of the box. The box itself contains a small vinyl model of various designs and colours.

The process of making a treasure box can be described as follows.
1. Obtain raw materials (i.e., cardboard and vinyl).
2. Decide on the model type.
3. For the packaging (i.e., box):
   1. Colour the raw cardboard to obtain a coloured net.
   2. Fold the coloured net to obtain a coloured box.
4. For the treasure box inside the packaging (i.e., toy):
   1. Mould the raw vinyl to obtain the shell of the toy.
   2. Colour the shell to obtain a coloured shell.
   3. Dry the colouring on the vinyl.
5. Package the treasure box (i.e., toy) inside the packaging (i.e., box).

This process can be summarised as the following.

![Process Image](./process.png)
